'use strict';

angular.module('nordTestApp')
  .controller('MainCtrl', function ($scope) {
        $scope.persons = {
            1: {
                id: 1,
                name: 'john smith',
                age: 22,
                gender: 'male'
            },
            2: {
                id: 2,
                name: 'jane doe',
                age: 30,
                gender: 'female'
            }
        };
        $scope.noPersons = $scope.persons=={};
        $scope.order='id';
        var newID = 1,
            newPerson;



        $scope.addPerson = function() {

            function newID() {
                var newID = 1;


                /*
                 * loop through the IDs until a free ID is found
                 */
                while (!!$scope.persons[newID]) {
                    newID++;
                }

                return newID;

            }

            newPerson = {
                id: newID(),
                name: $scope.name,
                age: $scope.age,
                gender: $scope.gender
            };

            //$scope.persons.push(newPerson);
            $scope.persons[newPerson.id] = newPerson;
        };


        $scope.removePerson = function(id) {
            //$scope.persons.splice(id-1, 1);
            delete $scope.persons[id];
        };



    });
